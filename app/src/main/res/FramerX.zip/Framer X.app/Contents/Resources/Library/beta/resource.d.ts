// This file enables importing from "framer/resource"
// The implementation of the url function is injected into the webpack module loader
// in the server loading webpack compilation proces

export function url(...src: string[]): string
