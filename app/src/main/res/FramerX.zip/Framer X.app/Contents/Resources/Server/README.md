# Framer CLI

The Framer CLI allows for building and publishing your [Framer folder projects](https://framer.gitbook.io/teams/integrations#folder-projects) via the command line.

<details>
<summary>Table of Contents</summary>

-   [Installation](#installation)
    -   [Local](#local)
    -   [Global](#global)
-   [Commands](#commands)
    -   [`build`](#build)
    -   [`publish`](#publish)
        -   [Options](#options)
        -   [Versioning](#versioning)
-   [Integration](#integration)
    -   [npm scripts](#npm-scripts)
    -   [CI](#ci)

</details>

## Installation

### Local

Because Framer projects are [just JavaScript packages](https://framer.gitbook.io/teams/integrations#framer-projects), the `framer-cli` package can be installed directly inside the [Framer folder project](https://framer.gitbook.io/teams/integrations#folder-projects), use either `yarn` or `npm`:

```sh
yarn add -D framer-cli
# or
npm install --save-dev framer-cli
```

This will make a `framer` command available to be run by inside the directory with either `yarn`, `npx`, or by directly calling the `bin` file:

```sh
yarn framer
# or
npx framer
# or
./node_modules/.bin/framer
```

### Global

Sometimes, it might be helpful to have the CLI globally available when managing multiple Framer packages. For these cases, the `framer-cli` package can also be installed globally:

```sh
yarn global add framer-cli
# or
npm install -g framer-cli
```

Similar to a local installation, the global installation makes the `framer` command available via the command line, but without needing a prefix:

```sh
framer
```

## Commands

The Framer CLI exposes two commands:

-   `build`
-   `publish`

### `build`

```sh
yarn framer build [path/to/project.framerfx]
```

The `build` command ensures that the project is in a valid state for publishing.

If the command is being run inside the Framer project, there is no need to specify the path to the project. However, if the command is being run from outside the project, the project path must be provided as a second argument.

### `publish`

> The `publish` command requires that the Framer project has already been published at least once via the FramerX application.

```sh
FRAMER_TOKEN=<token> yarn framer publish [path/to/project.framerfx] [--yes] [--major] [--public]
```

The `publish` command is responsible for:

1. Building the project
1. Managing project versioning (defaults to minor version)
1. Publishing the project to the store

The `publish` command requires a `FRAMER_TOKEN` environment variable for publishing. This token is unique to a given individual and is used for both authentication and determining the user's available private store, if any.

If a path to a project is provided, that path is resolved relative to the directory where the script is called from.

#### Options

The `publish` command also exposes a series of command line options:

| **Option** | **Description**                                                                                                            | **Default** |
| ---------- | -------------------------------------------------------------------------------------------------------------------------- | ----------- |
| `yes`      | Automatically confirm all prompts. This is especially useful when publishing from a CI.                                    | **false**   |
| `major`    | Override the default versioning strategy (minor bump) to instead use a major version bump.                                 | **false**   |
| `public`   | Publish the package to the public Framer store. This flag must be set if the user does not have access to a private store. | **false**   |

You can also see the available options in the terminal by running:

```sh
yarn framer help
```

#### Versioning

By default, `framer-cli` will look at the Framer repository to find the last published version and then publish the Framer package with the next version, either a minor or major bump depending on the CLI arguments.

However, it is possible to override this behavior by manually updating `package.json` version property. If the new version is higher than the last published version, it will be used without any change.

## Integration

### npm scripts

The `framer-cli` package can be used as part of any [`package.json` script](https://docs.npmjs.com/misc/scripts), including inside of a Framer project:

```json
{
  ...
  "scripts": {
    "build": "framer build",
    "publish": "framer publish",
    "publish:ci": "framer publish --yes",
    ...
  },
  "devDependencies": {
    "framer-cli": "latest",
    ...
  }
}
```

This allows the `framer` command to be run without calling it by name:

```sh
yarn build
FRAMER_TOKEN=<SECRET> yarn publish
```

Additionally, using the `framer` command as part of an npm script allows for defaults, while still supporting additional arguments:

```sh
FRAMER_TOKEN=<SECRET> yarn publish:ci --major
# will publish the package to the public store with a major version bump
```

### CI

One of the key aspects of `framer-cli` is the enablement of automated Framer package publishing. By combining the script with a CI workflow, it becomes possible to always keep the Framer package in the store in sync with the Framer package in the repository.

As an example, here is a small [CircleCI configuration](https://circleci.com/docs/2.0/configuration-reference) that uses the above `package.json` npm scripts to test and publish a Framer package.

_Note that this example assumes that the `FRAMER_TOKEN` environmental variable has already been set in the [CI project settings](https://circleci.com/docs/2.0/env-vars/#setting-an-environment-variable-in-a-project)._

<!-- prettier-ignore -->
```yml
# Javascript Node CircleCI 2.0 configuration file
#
# Check https://circleci.com/docs/2.0/language-javascript/ for more details
#
version: 2
jobs:
  publish:
    docker:
      - image: circleci/node:10

    working_directory: ~/repo

    steps:
      - checkout
      - run: yarn
      - run: yarn publish:ci

  test:
    docker:
      - image: circleci/node:10

    working_directory: ~/repo

    steps:
      - checkout
      - run: yarn
      - run: yarn test

workflows:
  version: 2
  test-and-publish:
    jobs:
      - test
      - publish:
          requires:
            - test
          filters:
            branches:
              only: master
```
